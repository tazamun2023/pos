<?php

return [
    'name' => 'Project',
    'module_version' => '2.0',
    'pid' => 5,
];
