<?php

return [
    'connector_module' => 'Módulo Conector',
    'connector' => 'Conector',
    'create_client' => 'Criar Cliente',
    'client_secret' => 'Segredo do Cliente',
    'clients' => 'Clientes',
    'documentation' => 'Documentação',
];
