<style type="text/css">
  .tags-look .tagify__dropdown__item{
    display: inline-block;
    border-radius: 3px;
    padding: .3em .5em;
    border: 1px solid #CCC;
    background: #F3F3F3;
    margin: .2em;
    font-size: .85em;
    color: black;
    transition: 0s;
  }

  .tags-look .tagify__dropdown__item--active{
    color: black;
  }

  .tags-look .tagify__dropdown__item:hover{
    background: lightyellow;
    border-color: gold;
  }
</style>