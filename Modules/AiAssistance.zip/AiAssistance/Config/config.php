<?php

return [
    'name' => 'AiAssistance',
    'module_version' => '1.0',
    'pid' => 17,
];
