<?php

namespace Modules\Superadmin\Entities;

use Illuminate\Database\Eloquent\Model;

class SuperadminFrontendPage extends Model
{
    protected $guarded = ['id'];
}
