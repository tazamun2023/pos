<?php

return [
    'spreadsheet' => 'Bảng tính',
    'spreadsheet_module' => 'Mô-đun bảng tính',
    'sheets' => 'Trang tính',
    'my_spreadsheets' => 'Bảng tính của tôi',
    'create_spreadsheet' => 'Tạo bảng tính',
    'no_spreadsheet_found' => 'Không tìm thấy bảng tính!',
    'view_spreadsheet' => 'Xem bảng tính',
    'share' => 'Chia sẻ',
    'share_excel' => 'Chia sẻ bảng tính',
    'todos' => 'Việc cần làm',
    'access_spreadsheet' => 'Truy cập bảng tính',
    'create_spreadsheet' => 'Tạo bảng tính',
    'spreadsheet_shared_notif_text' => ': shared_by đã chia sẻ một bảng tính -: name',
    'shared_by' => 'Được chia sẻ bởi:: name',
    'created_by' => 'Tạo bởi:: name',
];
