<?php

return [
    'spreadsheet' => 'Planilha',
    'spreadsheet_module' => 'Módulo de planilha',
    'sheets' => 'Folhas',
    'my_spreadsheets' => 'Minhas planilhas',
    'create_spreadsheet' => 'Criar planilha',
    'no_spreadsheet_found' => 'Nenhuma planilha encontrada!',
    'view_spreadsheet' => 'Ver planilha',
    'share' => 'Compartilhada',
    'share_excel' => 'Compartilhar planilha',
    'todos' => 'Todos',
    'access_spreadsheet' => 'Acessar planilha',
    'create_spreadsheet' => 'Criar planilha',
    'spreadsheet_shared_notif_text' => ':shared_by compartilhou uma planilha - :name',
    'shared_by' => 'Compartilhado por : :name',
    'created_by' => 'Criado por: :name',
];
